# datasetCleaner
A dataset cleaner for pictures

## Order :
### datasetCleaner.clean(path)
this function delete all the bugged images in the path. <br /> (⚠️ATTENTION⚠️ : this order erase all files who arn't images in the path like text files, vidéos, folders and more)
